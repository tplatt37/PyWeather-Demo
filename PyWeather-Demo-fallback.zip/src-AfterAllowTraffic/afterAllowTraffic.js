'use strict';
    
const AWS = require('aws-sdk');
const codedeploy = new AWS.CodeDeploy({apiVersion: '2014-10-06'});
var lambda = new AWS.Lambda();

exports.handler = (event, context, callback) => {

	console.log("Entering PostTraffic Hook!");
	
	// Read the DeploymentId and LifecycleEventHookExecutionId from the event payload
	var deploymentId = event.DeploymentId;
	var lifecycleEventHookExecutionId = event.LifecycleEventHookExecutionId;

	var functionToTest = process.env.NewVersion;
	console.log("AfterAllowTraffic hook tests started");
	console.log("Testing new function version: " + functionToTest);

	// Create parameters to pass to the updated Lambda function 
	// If you want to simulate a HOOK failure, you can change the Payload here to have something 
	// other than "city" which will cause the Lambda to fail.
	var lambdaParams = {
		FunctionName: functionToTest,    
		Payload: "{\"queryStringParameters\": {\"city\": \"Scranton\"}}", 
		InvocationType: "RequestResponse"
	};

	var lambdaResult = "Failed";

	// Invoke the updated Lambda function, for the city named above.
	// We simply make sure the Lambda works.  A more robust implementation
	// would check the response in detail.
	lambda.invoke(lambdaParams, function(err, data) {
		
		if (err) {	// an error occurred
			console.log(err, err.stack);
			lambdaResult = "Failed";
		}
		else{	// successful response
			var result = JSON.parse(data.Payload);
			console.log("Result: " +  JSON.stringify(result));
			console.log("statusCode: " + result.statusCode);
		
			if (result.statusCode == "200"){
				console.log("Validation succeeded");
				lambdaResult = "Succeeded";
			}
			else {
				console.log("Validation failed");
				lambdaResult = "Failed";
			}
		}

		// Complete the PostTraffic Hook by sending CodeDeploy the validation status
		var params = {
			deploymentId: deploymentId,
			lifecycleEventHookExecutionId: lifecycleEventHookExecutionId,
			status: lambdaResult // status can be 'Succeeded' or 'Failed'
		};
		
		// Pass CodeDeploy the prepared validation test results.
		codedeploy.putLifecycleEventHookExecutionStatus(params, function(err, data) {
			if (err) {
				// Validation failed.
				console.log("CodeDeploy Status update failed");
				console.log(err, err.stack);
				callback("CodeDeploy Status update failed");
			} else {
				// Validation succeeded.
				console.log("CodeDeploy status updated successfully");
				callback(null, "CodeDeploy status updated successfully");
			}
		});
	});
}